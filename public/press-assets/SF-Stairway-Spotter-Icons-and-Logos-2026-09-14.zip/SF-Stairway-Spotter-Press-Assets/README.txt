SF STAIRWAY SPOTTER — PRESS ICON AND LOGO FILES
Prepared September 14, 2026

App icon
app-icon-1024.png: Original 1024 × 1024 iOS app icon, unchanged.
app-icon-512.png: Smaller PNG export of the same icon.

Logo files
stairway-mark-purple / stairway-mark-white: The four-column symbol from the app header.
horizontal-logo-purple / horizontal-logo-white: Press lockups pairing that symbol with the app name.
Each logo is supplied as scalable SVG and transparent PNG.
Mark PNGs: 1024 × 1024. Horizontal PNGs: 2400 × 320.

Use purple logos on light backgrounds and white logos on dark backgrounds.
White transparent files may appear blank against a white preview background.
Keep proportions unchanged; do not stretch or recolor the files.
The original app icon has a square background; platforms apply their own corner mask.

The horizontal lockups are new press exports, not a screenshot of the app.
Their SVG text uses Arial Bold (with Helvetica/sans-serif fallbacks).
Use the PNG version when exact, font-independent appearance is important.
Brand purple: #4B3CE0.

Contact: info@urbanhikersf.com
Website: https://www.sfstairwayspotter.com

preview.jpg is a contact sheet for choosing files, not a standalone logo.
