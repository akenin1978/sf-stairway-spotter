SF STAIRWAY SPOTTER — PRESS KIT
Prepared September 17, 2026

App icon
app-icon-1024.png: Updated 1024 × 1024 press icon with clean circles and no beveled rims.
app-icon-512.png: Smaller PNG export of the same icon.

Logo files
stairway-mark-purple / stairway-mark-white: The four-column symbol from the app header.
horizontal-logo-purple / horizontal-logo-white: Press lockups pairing that symbol with the app name.
Each logo is supplied as scalable SVG and transparent PNG.
Mark PNGs: 1024 × 1024. Horizontal PNGs: 2400 × 320.

Use purple logos on light backgrounds and white logos on dark backgrounds.
White transparent files may appear blank against a white preview background.
Keep proportions unchanged; do not stretch or recolor the files.
The press icon has a square background; platforms apply their own corner mask.

The horizontal lockups are new press exports, not a screenshot of the app.
Their SVG text uses Arial Bold (with Helvetica/sans-serif fallbacks).
Use the PNG version when exact, font-independent appearance is important.
Brand purple: #4B3CE0.

Contact: info@urbanhikersf.com
Website: https://www.sfstairwayspotter.com

preview.html is a local contact sheet for choosing files. Open it in a browser.

The updated color icon is an export of the approved image-generated artwork.
It is a raster PNG, not a vector file. The installed Build 30 app still uses
the earlier icon; these press exports do not change the installed app.
The separate purple and white logo variants are unchanged.


Screenshots
Four original 1179 × 2556 iPhone screenshots are in screenshots/.
See CAPTIONS.txt for suggested captions and image order.
The screenshots are unchanged, with no retouching, cropping, or invented activity.

Press information
PRESS-RESOURCES.md contains the current press copy.
This kit does not include a founder headshot or standalone stairway photographs.
Contact info@urbanhikersf.com to request those assets or confirm usage rights.
